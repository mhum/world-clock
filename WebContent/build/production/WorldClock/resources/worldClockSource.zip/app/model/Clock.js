Ext.define('WorldClock.model.Clock', {
    extend: 'Ext.data.Model',
    fields: ['offset', 'office', 'open', 'close']
});