Ext.define('WorldClock.model.TimeZone', {
    extend: 'Ext.data.Model',
    fields: ['offset', 'display']
});