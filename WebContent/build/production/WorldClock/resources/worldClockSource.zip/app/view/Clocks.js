Ext.define('WorldClock.view.Clocks', {
    extend: 'Ext.container.Container',
    alias: 'widget.clocks',
    id:'clockContainer',
	layout:'hbox'
});