Ext.define('WorldClock.Application', {
    name: 'WorldClock',
    extend: 'Ext.app.Application',
    controllers:['Offices'],
    launch: function() {
	
    }
});
