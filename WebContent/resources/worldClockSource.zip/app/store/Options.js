Ext.define('WorldClock.store.Options', {
    extend: 'Ext.data.Store',
    model: 'WorldClock.model.Options'
});