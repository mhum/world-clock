Ext.define('WorldClock.store.Clocks', {
    extend: 'Ext.data.Store',
    model: 'WorldClock.model.Clock'
});