Ext.define('WorldClock.model.OpenHours', {
    extend: 'Ext.data.Model',
    fields: ['value']
});