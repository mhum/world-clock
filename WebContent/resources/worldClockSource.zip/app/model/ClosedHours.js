Ext.define('WorldClock.model.ClosedHours', {
    extend: 'Ext.data.Model',
    fields: ['value']
});