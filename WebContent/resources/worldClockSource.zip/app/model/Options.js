Ext.define('WorldClock.model.Options', {
    extend: 'Ext.data.Model',
    fields: ['fontSize', 'map']
});