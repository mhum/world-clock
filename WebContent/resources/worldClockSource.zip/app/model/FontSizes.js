Ext.define('WorldClock.model.FontSizes', {
    extend: 'Ext.data.Model',
    fields: ['display', 'value']
});