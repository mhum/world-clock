Ext.define('WorldClock.view.UpdateOffice', {
	extend: 'WorldClock.view.AddOffice',
    alias: 'widget.updateoffice',
    itemId:'updateOfficeWin',
    title: 'Update Office'
});